## What's new in Blast Pulse 1.4

- **Connection details at a glance:** Blast Pulse can now read the connection transport and quality directly from the Horizon Agent, without opening the Horizon Blast tray menu.
- **Up-to-date quality:** GOOD, OK and POOR update as the connection changes. The display shows when the information was last checked and does not attach an older log score to a current status.
- **More reliable session matching:** Connection information is associated with the active Horizon session and connection. When a direct value is unavailable, a matching log entry can still be used; its original timestamp is retained.
- **Safer handling of reconnects:** Information from an earlier connection is not presented as confirmed information for a new connection.

The direct read currently supports the tested Horizon Agent build; other builds fall back to available log information. Blast Pulse uses an internal Agent interface, which may change in future Horizon versions.
