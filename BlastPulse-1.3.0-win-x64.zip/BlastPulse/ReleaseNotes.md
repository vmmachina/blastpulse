## English

Blast Pulse 1.3.0 adds **Blast datagram maximum**, **Safe datagram TX** (Agent → client) and **Safe datagram RX** (client → Agent). Each value shows its own last log time. New matching records update the corresponding value; these are reported Blast sizes, not measured IP or path MTU.

The previous test build could show **Not reported** even with a readable log because Windows denied direct access to the SYSTEM-owned worker's start time. A local WMI fallback now verifies the worker without elevation or permission changes. Missing or ambiguous session/worker/connection context still shows **Not reported**, with the reason in the footer. Delayed or repeated disconnect notifications are also handled correctly when identifying a new connection.

**Validation:** automated Windows checks passed. User testing confirmed all three values at **1372 bytes** in a live Horizon session. Real mid-session size changes and the corrected binary's reconnect behavior have not yet been manually confirmed.

**Update:** exit the old tray instance, replace the EXE and restart. Keep your existing `config.json`. The ZIP includes English/German offline guides. Windows 10/11 x64 and .NET Framework 4.8; the EXE is unsigned.

## Deutsch

Blast Pulse 1.3.0 ergänzt **Blast-Datagrammmaximum**, **Sicheres Datagramm TX** (Agent → Client) und **Sicheres Datagramm RX** (Client → Agent). Jeder Wert zeigt seinen eigenen letzten Logzeitpunkt. Neue passende Einträge aktualisieren den jeweiligen Wert. Die Angaben sind protokollierte Blast-Größen, keine gemessene IP- oder Pfad-MTU.

Die vorige Testfassung konnte trotz lesbarem Log **Nicht gemeldet** anzeigen, weil Windows den direkten Zugriff auf die Startzeit des SYSTEM-Workers verweigerte. Ein lokaler WMI-Fallback prüft die Worker-Identität jetzt ohne erhöhte Rechte oder geänderte Berechtigungen. Ohne eindeutigen Sitzungs-/Worker-/Verbindungskontext bleibt die Anzeige **Nicht gemeldet**; die Fußzeile nennt den Grund. Verspätete oder mehrfache Trennungsmeldungen werden bei der Zuordnung einer neuen Verbindung ebenfalls berücksichtigt.

**Prüfung:** automatisierte Windows-Tests bestanden. Der Nutzertest bestätigte alle drei Werte mit **1372 Bytes** in einer laufenden Horizon-Sitzung. Ein echter Größenwechsel während der Sitzung und das Reconnect-Verhalten der korrigierten EXE sind noch nicht manuell bestätigt.

**Update:** alte Tray-Instanz beenden, EXE ersetzen und neu starten. Eigene `config.json` behalten. Das ZIP enthält die Offline-Anleitungen auf Englisch und Deutsch.
