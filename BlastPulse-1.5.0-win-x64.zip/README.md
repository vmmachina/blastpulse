<div align="center">
<p><img src="assets/banner-en.png" alt="Blast Pulse — Omnissa Horizon" width="1200"></p>
<p>by <strong>Stefan Gourguis</strong> · Omnissa Tech Insider · solvig. GmbH · solvig.ch</p>
<p><kbd>Version 1.5.0</kbd> &nbsp; <kbd>Windows x64</kbd> &nbsp; <kbd>.NET Framework 4.8</kbd></p>
<p><a href="https://github.com/vmmachina/blastpulse/blob/main/README.md"><kbd>English</kbd></a> | <a href="https://github.com/vmmachina/blastpulse/blob/main/README.de.md"><kbd>Deutsch</kbd></a></p>
<p><a href="https://github.com/vmmachina/blastpulse/releases/download/v1.5.0/BlastPulse.exe"><img src="assets/download-exe-en.png" alt="Download EXE" width="280"></a> &nbsp; <a href="https://github.com/vmmachina/blastpulse/releases/download/v1.5.0/BlastPulse-1.5.0-win-x64.zip"><img src="assets/download-zip-en.png" alt="Download Windows ZIP" width="280"></a></p>
</div>

The idea came from a simple inconvenience: checking a connection meant repeatedly opening the original Horizon Blast tray icon at the bottom right of the screen. Blast Pulse keeps the relevant information visible on the desktop, so you can follow your session while you work.

The compact display shows connection details alongside Blast FPS, round-trip time (RTT) and uplink packet loss. Live counters refresh every second by default. It appears as a transparent layer at the bottom right of the primary desktop, beneath ordinary application windows. Your wallpaper remains the background; it is not rewritten for each update.

## Latest release — 1.5.0

- Optional automatic Teams connection reports, including SlimCore, with original source and check times.
- Separate Teams channel activity and historical diagnostic imports; connection/process checks prevent accepting a report from before the current context.
- NVIDIA sections stay hidden until a GPU has actually been observed, avoiding transient sections on desktops without NVIDIA.

[Downloads and full release notes](https://github.com/vmmachina/blastpulse/releases/latest)

## In action

<p align="center"><img src="assets/screenshot-nvidia.png" alt="Blast Pulse 1.2 showing NVIDIA A2-16Q, driver 581.42, vGPU Guest mode and an Unlicensed badge" width="900"></p>

NVIDIA GPU and licensing information, shown at 192 DPI. The license state comes from the guest driver.

<p align="center"><img src="assets/screenshot-desktop.png" alt="Blast Pulse on the desktop beside a video of the Omnissa ONE keynote" width="1100"></p>

Horizon session during video playback. Metrics and log timestamps vary by session.

<p align="center"><img src="assets/screenshot-teams-slimcore.png" alt="Blast Pulse 1.5 Teams-reported SlimCore connection with original and checked times" width="900"></p>

Automatic Teams-reported SlimCore connection, shown separately from channel activity and an older imported diagnostic.

## Download and start

Download [Blast Pulse 1.5.0 for Windows x64 (ZIP)](https://github.com/vmmachina/blastpulse/releases/download/v1.5.0/BlastPulse-1.5.0-win-x64.zip). The package contains the application, an example configuration and the release notes.

The [release page](https://github.com/vmmachina/blastpulse/releases/tag/v1.5.0) also offers the [standalone EXE](https://github.com/vmmachina/blastpulse/releases/download/v1.5.0/BlastPulse.exe), [config.json](https://github.com/vmmachina/blastpulse/releases/download/v1.5.0/config.json) and [SHA-256 checksums](https://github.com/vmmachina/blastpulse/releases/download/v1.5.0/SHA256SUMS.txt).

You need Windows 10/11 x64, .NET Framework 4.8 and an active Horizon Blast session with readable session counters and logs. The application is unsigned.

1. Extract the ZIP into a local folder or an accessible network share.
2. Run `BlastPulse.exe` inside your Horizon Blast session.
3. The desktop display appears and updates automatically.

Right-click the Blast Pulse icon in the notification area next to the clock to change **Language → English / Deutsch**, **Hide/Show desktop display**, or **Exit Blast Pulse**. English is the default. A language change takes effect immediately and is remembered for your Windows user.

## Adjust the display

Place `config.json` beside `BlastPulse.exe` and restart Blast Pulse after editing it. Without this file, the defaults below apply.

| Setting | Default | Purpose and allowed values |
| --- | --- | --- |
| `RefreshSeconds` | `1` | Live counter refresh interval, 1–3600 seconds |
| `LogRefreshSeconds` | `5` | Log and display-information refresh interval, 1–3600 seconds |
| `PanelWidth` | `640` | Preferred display width at 96 DPI, 460–900 logical pixels |
| `Margin` | `30` | Distance from the right edge at 96 DPI, 12–150 logical pixels |
| `BottomOffset` | `150` | Space below the display at 96 DPI, 0–1000 logical pixels |
| `FontSize` | `11` | Preferred text size, 10–22 points |
| `FontFamily` | `"Segoe UI"` | Installed Windows font; Windows substitutes a font if unavailable |
| `Language` | `"en"` | Initial language: `"en"` or `"de"` |
| `ShowTeamsChannel` | `false` | Enable the optional Teams section in the normal desktop display; `true` or `false` |

Panel width, margins and text scale together with the current Windows DPI. The pixel settings above refer to 100% scaling (96 DPI). Resolution and DPI changes are picked up while the application is running; editing `config.json` still requires a restart. Long labels, values and footer lines wrap, and the display height is measured from their actual text. If the desktop is too small, the text size is reduced only as far as needed.

The default bottom offset leaves room for existing BGInfo text. For a narrower display directly above the taskbar, use this complete `config.json`; omitted settings retain their defaults:

```json
{
  "PanelWidth": 460,
  "Margin": 20,
  "BottomOffset": 0,
  "FontSize": 11
}
```

The language selected in the tray is saved in `%LOCALAPPDATA%\BlastPulse\preferences.json` and takes priority over `Language` in the shared configuration. To return to the configured language, exit Blast Pulse, remove that preference file and start it again. Users only need read access to `config.json`, including when it is on a network share.

## Start from a share or GPO

Keep `BlastPulse.exe` and `config.json` together on the share. Users need read/execute access. To start it at sign-in, add a command like this to a **user logon script**:

```bat
start "" "\\example.com\SYSVOL\example.com\scripts\BlastPulse\BlastPulse.exe"
```

Replace the example path with your own UNC or local path. Blast Pulse keeps running in the user's session, so the logon script should not wait for it to exit. The application does not set up autostart itself. Existing BGInfo can run alongside it; adjust `BottomOffset` to leave enough space.

No fixed delay is needed in the logon script. If Explorer is still starting, Blast Pulse checks again without blocking the UI, for up to two minutes per initialization. After that, timed retries stop; new shell/session activity or choosing **Show desktop display** can trigger detection again. Failures and recovery are recorded in `%LOCALAPPDATA%\BlastPulse\desktop.log`.

For an update, exit Blast Pulse, replace the EXE and start it again. Keep your existing `config.json` to preserve your layout. Test share access and your organisation's application policies before wider deployment.

## Data sources

Blast Pulse reads data locally on the Windows desktop. For the tested Agent build it reads transport and quality through the Agent's internal `wavedll.dll` interface; this is not a documented public API and may change. Other builds fall back to matching log information when available. It does not query a Horizon Connection Server API, require credentials or upload collected values to an external service.

| Desktop information | Source |
| --- | --- |
| RTT and uplink packet loss | `Win32_PerfFormattedData_Counters_HorizonBlastSessionCounters`: `RTT`, `PacketLossUplink` |
| Blast FPS | `Win32_PerfFormattedData_Counters_HorizonBlastImagingCounters`: `Framespersecond` |
| Codec name and screen capture method | Latest matching `Created region encoder` and `Screen capture name` entries in the session's Blast-Worker log |
| Connection transport and quality | Direct Agent query on the supported build; otherwise a matching session log entry, when available. A log score is only shown with its own log status. |
| Display driver, resolution and refresh rate | `Win32_VideoController`, filtered to devices whose name contains `Horizon` |
| Primary screen position and DPI | Windows screen bounds and desktop graphics DPI |

Both performance-counter classes are read through WMI in `root\cimv2`. Blast Pulse selects the counter instance whose `Name` starts with `Session ID: <current session ID>;`.

The compact desktop view prioritizes the six original connection details: codec, capture method, display device, screen configuration, transport and Horizon quality. Blast FPS, RTT and uplink packet loss appear beneath them. **Blast FPS describes the desktop transmission, not the source video's playback frame rate.**

The log file is:

```text
%ProgramData%\Omnissa\Horizon\Logs\Blast-Worker-SessionId<session ID>.log
```

For codec, capture and quality, only the last 4 MiB are read. Those log values represent the latest matching entry in that section and may be older than the current counter readings. The codec name comes directly from the log; no numeric encoder-to-codec mapping is assumed.

Transport and quality are queried together for the current connection on the tested Agent build. The display shows the query completion time; a direct quality state has no numeric score. If a direct value is unavailable, a matching log observation can be used with its own status, score and source time. Unverified or missing information is identified in the display rather than treated as confirmed.

A log quality status older than 90 seconds is marked as an older entry. Transport is not inferred from momentary traffic activity.

### Blast datagram sizes

Version 1.3.0 reads three additional values from the active session's Blast-Worker log:

| Display | Log source |
| --- | --- |
| Blast datagram maximum | `BlastSocketBuildUDPResponse` — negotiated maximum |
| Safe datagram TX | `BlastSocketUpdateSafeDatagramSendSize` — Agent → client |
| Safe datagram RX | `BlastSocketUpdateSafeDatagramReceiveSize` — client → Agent |

The log is checked at `LogRefreshSeconds`, five seconds by default. Each value keeps its own **last log time**. A new matching entry updates the corresponding value; an unchanged file does not become a new measurement. These are reported Blast datagram sizes, **not a measurement of the IP or path MTU**.

Before accepting a value, Blast Pulse verifies the current `VMBlastW` worker's session, PID and start time against the log and identifies its connection interval. If direct access to the start time is denied, it reads `ProcessId`, `SessionId` and `CreationDate` through the local `Win32_Process` WMI provider. No elevation or process-permission changes are used. Missing or ambiguous context shows **Not reported**, with a reason in the footer.

The incremental reader handles complete appended UTF-8/UTF-16 lines and checks for file replacement, truncation and history gaps. Each poll reads at most 4 MiB plus a small header. A new connection or worker requires verified context; rotated archives are not combined. Size records have no socket identifier, so they are associated with the worker/connection interval rather than individual simultaneous raw channels. Available updates depend on what the installed Agent logs.

For a one-time JSON export, use `BlastPulse.exe -datagram-json "C:\Path\datagram.json"` within the target user's Horizon session. It writes a snapshot and exits. The export includes computer/session identifiers, worker and connection context, state and per-value source timestamps; consumers should check those fields. An unavailable size is `null`. `DiscoveryMtuBytes` remains `null`; logged search defaults are not proof that discovery completed. Blast Pulse sends no MTU probes and changes no network settings.

## Microsoft Teams and SlimCore

The Teams section is optional. Add `"ShowTeamsChannel": true` to `config.json` beside the EXE and restart Blast Pulse. Without this setting it remains hidden and is not polled. Use the normal desktop mode, without `-preview` or `-apply`.

Blast Pulse reads the user-local Teams monitoring file every five seconds:

```text
%LOCALAPPDATA%\Packages\MSTeams_8wekyb3d8bbwe\LocalCache\Microsoft\MSTeams\tfw\vdi_connection_info.json
```

This uses [Microsoft's documented Teams monitoring data](https://learn.microsoft.com/en-us/microsoftteams/vdi-2#monitoring-api). Availability depends on the installed Teams version and a readable file. Blast Pulse does not install Teams, the endpoint plug-in or SlimCore, and does not alter optimization policies.

| Display | Meaning |
| --- | --- |
| SlimCore connection reported | Teams reports `remote` / `3200`; the local process and connection checks accept the record. |
| SlimCore fallback reported | Teams reports `local` / `3200`. |
| WebRTC reported; state unconfirmed | Teams reports `local` / `3100`; this does not establish whether WebRTC media optimization is active. |
| Teams not running / Not determined | Teams is stopped, or no matching valid report is available; this is not proof of an unoptimized connection. |

The display keeps the original **Teams report time** separate from **Checked**. A connection event is not a heartbeat. Reports must follow the current Teams process start and Windows connection boundary; context changes, failed reads, conflicts and expired collected samples invalidate the positive display. Multiple sessions of the same Windows account are outside the supported attribution scope: these user-local records contain no validated Windows session/process identity. Observed Teams processes in another Windows session suppress positive attribution conservatively.

**Teams channel** is a separate observation from the session/worker-bound Horizon virtual-channel WMI counters. Observed traffic is not proof of media optimization. Collection runs in a bounded background process so a delayed provider does not block desktop updates.

The tray menu also offers **Import Teams diagnosis…** for supported TXT/ZIP diagnostics, including nested Weblogs, and **Clear imported Teams diagnosis**. A supported SlimCore confirmation appears under **Last confirmed (diagnostic)** with its original event time and any later detected disconnect. It is stored as selected evidence in `%LOCALAPPDATA%\BlastPulse\teams-diagnostic.json`, not as a raw diagnostic archive, and remains explicitly historical. It never overrides the automatic report.

Teams monitoring retains only the selected mode, stack and times from its source; it does not export raw monitoring data or account/device/call details. The existing datagram JSON export and wallpaper preview/apply modes do not include the Teams section. The reported connection is not an audio/video health test.

### NVIDIA data

The NVIDIA section reads the installed driver's **NVML** library locally. It does not launch `nvidia-smi`, query the DLS server or change licensing settings. No NVIDIA library is bundled with Blast Pulse.

| NVIDIA information | NVML source |
| --- | --- |
| GPU count | `nvmlDeviceGetCount_v2` — devices visible inside the Windows guest |
| GPU name | `nvmlDeviceGetName` |
| Virtualization mode | `nvmlDeviceGetVirtualizationMode` |
| Driver version | `nvmlSystemGetDriverVersion` |
| Licensed product and license status | `nvmlDeviceGetGridLicensableFeatures_v4` — product name, enabled flag and license state |

A supported, enabled feature is shown as **Licensed** or **Unlicensed**, as reported by the driver. Disabled features and unsupported licensing are identified separately. An unavailable query or a sample older than 90 seconds produces **Unknown**, rather than a guessed license state. The query runs in a separate process with a 10-second timeout so a stalled driver call does not hold up Blast sampling.

The desktop NVIDIA section stays hidden until a positive GPU count has been read. An initial timeout/error, no driver or zero GPUs cannot make it appear. Once a GPU has been observed, later query failures keep a visible unknown state; they do not preserve a positive license state. A new successful query restores the current driver-reported information.

A **Licensed** guest does not by itself prove a current connection to NVIDIA DLS; it describes the guest driver's reported license state. Blast Pulse does not read license-token files or call UUID, serial-number or license-server administration APIs. Tokens, GPU UUIDs, serial numbers and server addresses are not included in the display.

## Compatibility

Blast Pulse 1.5.0 for Windows x64.

For 1.5, user-assisted checks of the preceding functionally equivalent Teams test build in a real Horizon VDI confirmed automatic SlimCore display, the stopped state, reopening Teams with a fresh report and a fresh report after reconnecting the same Windows session. The reconnect gap itself was not recorded live. WebRTC/fallback, multiple same-account sessions and audio/video call health were not validated in that VDI. The final 1.5 Windows build is checked separately by the automated regression suite; its NVIDIA no-GPU correction is covered by controlled state-to-renderer tests.

The earlier 1.4 Windows build and automated regression suite passed. A Horizon VDI test of the preceding functionally equivalent test build confirmed BEAT (UDP), a GOOD-to-OK change, English/German display and reconnect with the same worker. The final 1.4 executable has not itself been tested in that VDI. Other Agent builds, a worker replacement, TCP/POOR transitions and multi-user operation remain unverified in live use.

The NVIDIA display was checked in a Horizon vGPU session with an NVIDIA A2-16Q, driver 581.42 and 192 DPI. All six NVIDIA values were visible; the driver reported **Unlicensed**. Other license states and multi-GPU layouts have not yet been checked on real hardware. Automated Windows regression checks passed for the 1.2 source revision, covering license-state handling, query timeouts, English/German text and DPI layouts.

The 1.1 baseline passed automated Windows rendering checks at 100%, 125%, 150%, 200% and 300% scaling, including large fonts and narrow panels. User testing in Horizon confirmed readable layouts at 3840 × 2160 with 192 DPI (200%) and 1920 × 1080 with 168 DPI (175%).

- The display uses the primary screen. Multiple monitors, Explorer restarts and session reconnects have not been comprehensively tested.
- Available information depends on the Horizon Agent version, log format and the user's access to the counters and logs.
- Test central deployment in your own environment before rollout.

## References

- [Omnissa: Blast performance counters](https://docs.omnissa.com/de-DE/Horizon-Remote-Desktop-Features-V2606/ExaminingBlastSessionStatisticswithWindowsPerformanceMonitor)
- [Omnissa: Blast logs and packet loss](https://kb.omnissa.com/s/article/89455)

- [NVIDIA: NVML vGPU queries](https://docs.nvidia.com/deploy/nvml-api/latest/api/group__nvmlVirtualGpuQueries.html)
- [NVIDIA: vGPU licensing troubleshooting](https://docs.nvidia.com/vgpu/latest/grid-licensing-user-guide/troubleshooting-grid-licensing.html)
